import nltk


def common_words(text):
    all_words = nltk.tokenize.TweetTokenizer(text).tokenize(text)
    stopwords = nltk.corpus.stopwords.words('english')
    filtered_words = nltk.FreqDist(w.lower() for w in all_words if w not in stopwords)  

    mostCommon = filtered_words.most_common()

    return mostCommon

def build_number_of_word_occurances(text, keywords):
    allWords = nltk.tokenize.TweetTokenizer(text).tokenize(text)
    stopwords = nltk.corpus.stopwords.words('english')
    filtered_words = nltk.FreqDist(w.lower() for w in allWords if w not in stopwords and w.lower() in keywords)  

    mostCommon = filtered_words.most_common()

    return mostCommon