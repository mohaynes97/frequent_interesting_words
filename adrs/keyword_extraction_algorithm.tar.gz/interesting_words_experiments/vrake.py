from ast import NamedExpr
from rake_nltk import Rake
from common_words import build_number_of_word_occurances

max_length=1
r = Rake(max_length=max_length, include_repeated_phrases=False)

with open("test_docs/doc6.txt", "r") as f:
    text = f.read()

r.extract_keywords_from_text(text)

keywords = r.get_ranked_phrases()[:10]

word_occurances = build_number_of_word_occurances(text, keywords)

print(word_occurances)

