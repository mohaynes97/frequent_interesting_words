from keybert import KeyBERT
from common_words import build_number_of_word_occurances

ngram_max = 1
kw_model = KeyBERT()

with open("test_docs/doc6.txt", "r") as f:
    text = f.read()

keywords = kw_model.extract_keywords(text, keyphrase_ngram_range=(1, ngram_max), top_n=10)
keywords = [w[0].lower() for w in sorted(keywords, key=lambda x: x[1])]

word_occurances = build_number_of_word_occurances(text, keywords)

print(word_occurances)
