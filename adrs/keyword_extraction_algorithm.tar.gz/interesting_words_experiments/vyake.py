from distutils.command.build import build
import yake
from common_words import build_number_of_word_occurances

kw_extractor = yake.KeywordExtractor()
language = "en"
max_ngram_size = 1
deduplication_threshold = 0.9
numOfKeywords = 100

with open("test_docs/doc6.txt", "r") as f:
    text = f.read()

custom_kw_extractor = yake.KeywordExtractor(lan=language, n=max_ngram_size, dedupLim=deduplication_threshold, top=numOfKeywords, features=None)
keywords = custom_kw_extractor.extract_keywords(text)
keywords = [w[0].lower() for w in sorted(keywords, key=lambda x: x[1])]
word_occurances = build_number_of_word_occurances(text, keywords)

print(word_occurances)